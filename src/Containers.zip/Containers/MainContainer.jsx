import React from "react";
import "./mainContainer.css";

export default function MainContainer() {
  return (
    <>
      <div className="mainContainer">
        <div className="left-Container">
          <p><span class="color">Aprender</span> de <span class="color"><br></br>finanzas</span> nunca fue <br></br>tan <span class="color">fácil</span>l </p>
        </div>
      </div>
    </>
  );
}
